<?php
add_post_type_support('page', 'excerpt');
add_post_type_support('post', 'excerpt');
remove_action('init', 'wp_admin_bar_init');
add_theme_support('menus', 'widget');
add_theme_support('post-thumbnails');
set_post_thumbnail_size(825, 510, true);
add_theme_support('title-tag');
add_theme_support('custom-background', array('default-color' => 'white'));
add_theme_support('custom-logo', array('height' => 90, 'width' => 90, 'flex-width' => true,));
add_filter('show_admin_bar', '__return_false');
register_nav_menu('menu_principal', 'Menu Principal - Topo');
//register_nav_menu('menu_rodape', 'Menu - rodape');



register_sidebar(array(
 "name" => "toposite",
 "description" => "contéudo do cabeçalho - anuncio",
 "id" => "toposite",
 "before_widget" => "<div class='conteudo_propaganda_topo'>",
 "after_widget" => "</div>",
));


/*
  register_sidebar(array(
  "name" => "lateralsite",
  "description" => "Anuncio na lateral da home, link, publicidade, etc",
  "id" => "lateralsite",
  "before_widget" => "<article class=\"col-sm-6  conteudo_lateral\">",
  "after_widget" => "</article>",
  ));
 */

require"Includes/custom_post.php";


add_shortcode('anuncio', 'ChamaAnuncios');

function ChamaAnuncios() {

    $args = array('post_type' => 'propaganda', 'post_parent' => "0", "posts_per_page" => "0", "offset" => 0, 'orderby' => 'date', 'order' => 'desc'); //,"offset"=>"2"// $args = array('post_type' => 'page', 'offset' => 1);
    $my_posts = get_posts($args);


    $id = $my_posts[0]->ID;
    if ($id != "")
    {
        $anuncio = "<article class=\"col-sm-6 conteudo_lateral\">"
                . get_the_post_thumbnail($id, $size = 'large', array("class" => "imagensIndex"))
                . "<span class='span2Anuncio'>"
                . "<h3>Anuncio</h3>"
                . "" . $my_posts[0]->post_title . "<br>" . $my_posts[0]->post_content . ""
                . "</span>"
                . $my_posts[0]->post_content
                . "</article>";
        return $anuncio;
    }
    else
    {
       $anuncio = "<article class=\"col-sm-6 conteudo_lateral\"><center><h2>Anuncie aqui</h2></center></article>";
        return $anuncio;
    }
}







