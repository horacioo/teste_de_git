<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link rel="profile" href="http://gmpg.org/xfn/11">
        <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
        <!--[if lt IE 9]>
        <script src="<?php echo esc_url(get_template_directory_uri()); ?>/js/html5.js"></script>
        <![endif]-->


        <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js" ></script>
        <script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
        <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"  rel="stylesheet" type="text/css">
        <link href="http://pingendo.github.io/pingendo-bootstrap/themes/default/bootstrap.css"  rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
        <?php wp_head(); ?>

    </head>
    <body class="custom-background">
        <div class="container">
            <header class="row">
                <div class="col-md-7 col-md-offset-5">
                    <?php
                    if (is_active_sidebar('Toposite'))
                    {
                        dynamic_sidebar('Toposite');
                    }
                    ?>
                </div>
            </header>
            <nav class="row" id="menu_topo">
                <div class="col-md-9"><?php get_template_part('partes_template/menu'); ?></div>
                <div class="col-md-3">
                    <form action=''  method="get"><input type="text" name="ref" class="form-control" placeholder="pesquisar"></form>
                </div>
            </nav>
            <div class="row menu_inferior">
                <div class="col-md-12">
                    <div class="col-xs-2">
                        <img class="seta4rodas" src="<?php echo get_template_directory_uri() ?>/img/seta_topo.png" alt="4_rodas" title="rodas">
                    </div>
                    <div class="col-xs-9">
                        <?php wp_list_categories(array("title_li" => "")); ?>
                    </div>
                </div>
            </div>