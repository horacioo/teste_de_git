<?php get_header(); ?>
<main class="row">

    <section class="col-sm-5 conteudo">
        <?php
        $args = array('post_type' => 'post', 'post_parent' => "0", "posts_per_page" => "1", 'orderby' => 'date', 'order' => 'desc'); //,"offset"=>"2"// $args = array('post_type' => 'page', 'offset' => 1);
        $my_posts = get_posts($args);
        foreach ($my_posts as $post): setup_postdata($post);
            $id = get_the_ID();
            $categories = get_the_category($id);
            $thumb = get_the_post_thumbnail($id, $size = 'large', array("class" => "imagensIndex")/* , array("class" => "img-responsive") */); //
            echo $thumb;
            echo"<span class='span'><a href='" . get_permalink() . "'><span class='categoria_conteudo'>" . $categories[0]->name . " </span>" . get_the_title() . "</a></span>";
        endforeach;
        ?>
    </section>




    <section class="col-sm-7">
        <?php
        $args = array('post_type' => 'post', 'post_parent' => "0", "posts_per_page" => "3", "offset" => 1, 'orderby' => 'date', 'order' => 'desc'); //,"offset"=>"2"// $args = array('post_type' => 'page', 'offset' => 1);
        $my_posts = get_posts($args);
        $total = 0;
        $anexo = "";
        foreach ($my_posts as $post): setup_postdata($post);
            $id = get_the_ID();
            $categories = get_the_category($id);

            if ($total === 1)
            {
                echo do_shortcode("[anuncio]");
            }
            $titulo = get_the_title();
            $thumb = get_the_post_thumbnail($id, $size = 'large', array("class" => "imagensIndex")/* , array("class" => "img-responsive") */); //
            echo "<article class=\"col-sm-6 conteudo_lateral\">$thumb";
            echo"<span class='span2'><a href='" . get_permalink() . "'><span class='categoria_conteudo'>" . $categories[0]->name . "</span>" . get_the_title() . "</a></span>";
            echo"</article>";
            $total++;
            
        endforeach;
        ?>

    </section>
</main>
<section class="row ptBaixa">
    <?php
    $args = array('post_type' => 'post', 'post_parent' => "0", "posts_per_page" => "4", 'offset' => 4, 'orderby' => 'date', 'order' => 'desc'); //,"offset"=>"2"// $args = array('post_type' => 'page', 'offset' => 1);
    $my_posts = get_posts($args);
    foreach ($my_posts as $post): setup_postdata($post);
        $id = get_the_ID();
        $categories = get_the_category($id);
        $thumb = get_the_post_thumbnail($id, $size = 'large', array("class" => "imagensIndex")/* , array("class" => "img-responsive") */); //
        echo"<article class=\"col-sm-3 Noticias_rodape\">";

        echo"<div class='noticiasBottom'>$thumb";
        echo"<div class='categoria'>" . $categories[0]->name . "</div>";
        echo"</div>";
        echo"<div class='titulo_rodape'><a href='" . get_the_permalink() . "'>" . get_the_title() . "</a></div>";
        echo"<div class='resumo_rodape'>" . get_the_excerpt() . "<div>";
        echo"<div class='mais_categorias_rodape'>+" . $categories[0]->name . "<div>";
        echo"</article>";
    endforeach;
    ?>

</section>
<?php
get_footer();
