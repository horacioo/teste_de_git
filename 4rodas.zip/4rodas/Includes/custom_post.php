<?php
registrar_propaganda();
function registrar_propaganda() {

  $descritivos = array(
    'name' => 'propaganda',
    'singular_name' => 'Anuncios',
    'add_new' => 'Adicionar Novo anúncio',
    'add_new_item' => 'Adicionar anúncio',
    'edit_item' => 'Editar anúncio',
    'new_item' => 'Novo anúncio',
    'view_item' => 'Ver anúncio',
    'search_items' => 'Procurar anúncio',
    'not_found' =>  'Nenhuma anúncio encontrado',
    'not_found_in_trash' => 'Nenhum anúncio na Lixeira',
    'parent_item_colon' => '',
    'menu_name' => 'Anúncio'
  );

  $args = array(
    'labels' => $descritivos,  //Insere o Array de labels dentro do argumento de labels
    'public' => true,  //Se o Custom Type pode ser adicionado aos menus e exibidos em buscas
    'hierarchical' => false,  //Se o Custom Post pode ser hierarquico como as páginas
    'menu_position' => 5,  //Posição do menu que será exibido
    'supports' => array('excerpt','title','editor','thumbnail', 'revisions') //Quais recursos serão usados (metabox)
    );

  register_post_type( 'propaganda' , $args );
  flush_rewrite_rules();


}
