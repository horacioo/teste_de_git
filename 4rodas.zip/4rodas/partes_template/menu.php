    <div class="navbar navbar-default ">
        <div class="container">
            <div class="navbar-header">
                <a href="<?php bloginfo('url'); ?>"><img src="<?php echo get_template_directory_uri() ?>/img/logo.png" class="logo_topo img-responsive" alt="logo_4_rodas" title="logo 4 rodas"></a>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <nav class="collapse navbar-collapse" id="navbar-ex-collapse">
                <?php wp_nav_menu(array('menu' => 'menu_principal', 'menu_class' => 'menu_principal nav navbar-nav navbar-left')); ?>
            </nav>
        </div>
    </div>