$(document).ready(function () {
    var height;
    var width;

    width = $(document).width();
    height = $(document).height();



    $(window).resize(function () {
        TamanhoTela();
    });

    ExecutaMenu(width);

});



function TamanhoTela() {
    width = $(document).width();
    height = $(document).height();
}


function ExecutaMenu(width) {
    $(".sub-menu").slideUp();
   // if (width > 768) {

        $("li").mouseover(function () {
            $(this).children(".sub-menu").slideDown("fast");
        });

        $("li").mouseleave(function () {
            $(this).children(".sub-menu").slideUp("fast");
        });
   /* } else
    {
        $(".sub-menu").slideDown("fast");
    }*/
}