<footer class="row"></footer>
</div>
<?php wp_footer() ?>

<?php
$tema = get_template_directory_uri();
$javascritp = $tema . "/js/";
?>
<script src="<?php echo $javascritp ?>index.js"></script>
</body>
</html>